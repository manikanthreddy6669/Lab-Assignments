import java.util.Scanner;

public class Program2 {
	int calculateDifference(int n) {
		int Sum = 0;
		Sum = (((n * (n + 1) * ((2 * n) + 1)) / 6) - (n * (n + 1) / 2) * (n * (n + 1) / 2));
		return Sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Program2 p = new Program2();
		System.out.println("Enter n");
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		System.out.println(p.calculateDifference(n));
		s.close();
	}

}
