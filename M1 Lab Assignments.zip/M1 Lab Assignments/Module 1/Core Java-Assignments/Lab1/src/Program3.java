import java.util.Scanner;

public class Program3 {
	boolean checkNumber(int number) {
		int count = 0, prev = 9999, r, n1;
		n1 = number;
		while (n1 > 0) {
			n1 = n1 / 10;
			count++;
		}

		while (number > 0) {
			r = number % 10;
			number = number / 10;
			if (r <= prev) {
				count--;
				prev = r;
			}
		}
		if (count == 0)
			return true;
		else
			return false;
	}

	public static void main(String[] args) {
		Program3 p = new Program3();
		Scanner s = new Scanner(System.in);
		System.out.println("enter number");
		int number = s.nextInt();
		System.out.println(p.checkNumber(number));
		s.close();
	}
}
