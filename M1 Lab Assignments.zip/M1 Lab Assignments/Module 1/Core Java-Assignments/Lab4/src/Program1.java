import java.util.Scanner;

public class Program1 {
void method(int n)
{ int sum=0,r;
	while(n>0)
	{
		r=n%10;
		n=n/10;
		sum=sum+(r*r*r);
	}
	System.out.println(sum);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Program1 p=new Program1();
Scanner s=new Scanner(System.in);
System.out.println("Enter n");
int n=s.nextInt();
p.method(n);
s.close();
	}

}
