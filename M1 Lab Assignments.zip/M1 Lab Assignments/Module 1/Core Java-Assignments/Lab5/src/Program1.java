import java.util.Scanner;

public class Program1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("1.Red\n2.Yellow\n3.Green");
		int n = s.nextInt();
		if (n == 1)
			System.out.println("STOP");
		else if (n == 2)
			System.out.println("READY");
		else if (n == 3)
			System.out.println("GO");
		else
			System.out.println("Invalid input");
		s.close();
	}

}
