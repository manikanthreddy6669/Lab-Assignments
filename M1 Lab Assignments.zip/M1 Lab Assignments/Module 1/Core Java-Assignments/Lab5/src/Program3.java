import java.util.Scanner;

public class Program3 {
	void primeNumber(int n) {
		int i, j, count = 0;
		for (i = 2; i <= n; i++) {
			count = 0;
			for (j = 1; j < i; j++)
				if (i % j == 0)
					count++;
			if (count == 1)
				System.out.print(i + ",");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Program3 p = new Program3();
		Scanner s = new Scanner(System.in);
		System.out.println("Enter n");
		int n = s.nextInt();
		p.primeNumber(n);
		s.close();
	}

}
