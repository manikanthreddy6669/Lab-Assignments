import java.util.Scanner;

class LoginCheck extends Throwable{
	public  LoginCheck(String msg)
	{super(msg);
	}
}
public class Program4 {
static void validate(String firstname,String lastname) throws LoginCheck{
	if(!(firstname.isEmpty() && lastname.isEmpty()))
		System.out.println("FirstName,LastName are valid");
	else
		throw new LoginCheck("FirstName,LastName are blank");

 }
public static void main (String[] args) throws LoginCheck {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter FirstName");
	String firstname="";//s.next();
	//System.out.println("Enter LastName");
	String lastname="";//s.next();
	Program4.validate(firstname,lastname);
	s.close();
}
}
