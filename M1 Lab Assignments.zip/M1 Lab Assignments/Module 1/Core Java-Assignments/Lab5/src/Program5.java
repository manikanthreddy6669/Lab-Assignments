import java.util.Scanner;

class InvalidAgexception extends Throwable{
	public  InvalidAgexception(String errorMsg)
	{super(errorMsg);
	}
}
public class Program5
{
	static void validation(int age) throws InvalidAgexception{
		if(age<15)
			throw new InvalidAgexception("Age of a person is below 15");
		else
			System.out.println("Age of a person is "+age);
	}
	public static void main(String[] args) throws InvalidAgexception {
		Scanner s=new Scanner(System.in);
		int age=s.nextInt();
		Program5.validation(age);
		s.close();
	}
}
