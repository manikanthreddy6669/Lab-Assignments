import java.util.Scanner;
import java.util.StringTokenizer;

class Program1 {
    public static void main(String args[]) {
        int n;
        int sum = 0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter integers");
        String s = sc.nextLine();
        StringTokenizer st = new StringTokenizer(s," ");
        while (st.hasMoreTokens()) {
            String s1 = st.nextToken();
            n = Integer.parseInt(s1);
            System.out.println(n);
            sum = sum + n;
        }
        System.out.println("Sum of numbers is: " + sum);
        sc.close();
    }
}