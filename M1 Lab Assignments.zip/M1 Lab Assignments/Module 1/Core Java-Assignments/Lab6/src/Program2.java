import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Program2 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter file name");
		String s1 = s.next();
		FileReader f = new FileReader(s1);
		BufferedReader b = new BufferedReader(f);
		String line = b.readLine();
		int i=1;
		while (line != null) {
			System.out.println("Line"+i+":"+line);
			line = b.readLine();
			i++;
		}
		b.close();
		s.close();
	}

}
