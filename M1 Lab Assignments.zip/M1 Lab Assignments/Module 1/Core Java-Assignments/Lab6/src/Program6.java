import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Program6 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		int wordcount = 1, chcount = 0, linecount = 0;
		Scanner s = new Scanner(System.in);
		System.out.println("Enter file name");
		String s1 = s.next();
		FileReader f = new FileReader(s1);
		BufferedReader b = new BufferedReader(f);
		String line = b.readLine();
		while (line != null) {
			linecount++;
			chcount = chcount + line.length();
			for (int i = 0; i < line.length(); i++)
				if (line.charAt(i) == ' ')
					wordcount++;
			line=b.readLine();
		}
		System.out.println("Number of Characters : " + chcount);
		System.out.println("Number of Words : " + (wordcount+linecount-1));
		System.out.println("Number of Lines : " + linecount);
		s.close();
		b.close();
	}

}
