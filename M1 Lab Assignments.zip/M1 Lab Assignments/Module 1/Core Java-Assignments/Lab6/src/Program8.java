import java.util.Scanner;

public class Program8 {
	boolean method(String s1) {
		int c = 0;
		char[] a = s1.toCharArray();
		for (int i = 0; i < a.length - 1; i++)
			if (a[i] <= a[i + 1])
				c++;
		if (c == (a.length - 1))
			return true;
		else
			return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Program8 p = new Program8();
		Scanner s = new Scanner(System.in);
		String s1 = s.next();
		System.out.println(p.method(s1));
		s.close();
	}

}
