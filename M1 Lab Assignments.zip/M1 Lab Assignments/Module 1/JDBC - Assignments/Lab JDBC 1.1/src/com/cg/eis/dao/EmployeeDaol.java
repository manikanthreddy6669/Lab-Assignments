package com.cg.eis.dao;

import java.util.ArrayList;
import com.cg.eis.bean.EmployeeBean;

public interface EmployeeDaol {

	int addEmployee(EmployeeBean employeeBean);
}
